<!-- Footer -->
<footer class="site-footer">
	<div class="site-footer-legal">Copyright © 2022 BURAPHA CIVIL 168 CO., LTD. All Rights Reserved.</div>
</footer>