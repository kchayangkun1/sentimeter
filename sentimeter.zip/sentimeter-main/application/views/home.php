<body style="background-image: url(assets/images/background/bg_sen.png);background-position: inherit;background-size: cover;" >
    <!-- <div class="container">
  <div class="row">
    <div class="col-4">Column</div>
    <div class="col-4">Column</div>
    <div class="col-4">Column</div>
  </div>
</div> -->

    <!-- se about -->
<section class="mt-5 pt-5"> 
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <div data-aos="fade-up" data-aos-duration="1000">

                </div>
                <h1 class="head-about">ABOUT <br> US</h1>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5"></div>
        </div><!-- se row 1 -->
        <div class="row mt-3">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
        </div><!-- se row 2 -->
    </div>
</section>

<!-- se 2 servicr -->
<section class="mt-5 pt-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-4" style="padding-left: 0px;padding-right: 0px;">
                <img src="<?=base_url('assets/images/service/service1.png');?>" style="width: 100%;" class="img-fluid ">
                <div class="centered"data-aos="fade-up"data-aos-duration="1000" >
                    <h3 class="card-title-h1 mt-1 ">SERVICE</h3>
                </div>
            </div>
            <div class="col-4" style="padding-left: 0px;padding-right: 0px;">
                <img src="<?=base_url('assets/images/service/service2.png');?>" style="width: 100%;" class="img-fluid ">
                    <div class="centered"data-aos="fade-up" data-aos-duration="1000" >
                    <h3 class="card-title-h1 mt-1 ">WORK</h3>
                </div>
            </div>
            <div class="col-4" style="padding-left: 0px;padding-right: 0px;">
                <img src="<?=base_url('assets/images/service/service3.png');?>" style="width: 100%;" class="img-fluid ">
                    <div class="centered"data-aos="fade-up" data-aos-duration="1000" >
                <h3 class="card-title-h1 mt-1">CONTACT</h3>
            </div>
        </div>
    </div>
</section>
<!-- se 3 about 2 -->
<section class="mt-5 pt-5 mb-5"> 
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <h1 class="head-about">ABOUT <br> US 2</h1>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5"></div>
        </div><!-- se row 1 -->
        <div class="row mt-3">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
        </div><!-- se row 2 -->
    </div>
</section>
</body>

    
   