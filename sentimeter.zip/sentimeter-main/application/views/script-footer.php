<!--====== jquery js ======-->
    <script src="<?=base_url('assets/js/vendor/modernizr-3.6.0.min.js');?>"></script>
    <script src="<?=base_url('assets/js/vendor/jquery-1.12.4.min.js');?>"></script>
    <!--====== Bootstrap js ======-->
    <script src="<?=base_url('assets/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/js/popper.min.js');?>"></script>
    <!--====== Slick js ======-->
    <script src="<?=base_url('assets/js/slick.min.js');?>"></script>
    <!--====== Isotope js ======-->
    <script src="<?=base_url('assets/js/isotope.pkgd.min.js');?>"></script>
    <!--====== Images Loaded js ======-->
    <script src="<?=base_url('assets/js/imagesloaded.pkgd.min.js');?>"></script>
    <!--====== Magnific Popup js ======-->
    <script src="<?=base_url('assets/js/jquery.magnific-popup.min.js');?>"></script>
    <!--====== Scrolling js ======-->
    <script src="<?=base_url('assets/js/scrolling-nav.js');?>"></script>
    <script src="<?=base_url('assets/js/jquery.easing.min.js');?>"></script>
    <!--====== wow js ======-->
    <script src="<?=base_url('assets/js/wow.min.js');?>"></script>
    <!--====== Main js ======-->
    <script src="<?=base_url('assets/js/main.js');?>"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <SCript>
          AOS.init();
    </SCript>