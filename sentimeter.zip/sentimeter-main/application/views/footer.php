 <!--====== FOOTER FOUR PART START ======-->

 <footer id="footer" class="footer-area" style="background-color: black;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <div class="footer-logo text-center mt-10">
                    <a href="<?=base_url('home');?>"><img src="<?=base_url('assets/images/logo/LOGO_SENTIMETER_footer.png');?>" alt="Logo"></a>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 mt-5">
                <div class="footer-link">
                    <h6 class="footer-title"style="color: #fff;"></h6>
                        <li><a href="#" style="color: #fff;">HOME</a></li>
                        <li><a href="#" style="color: #fff;">SERVICE</a></li>
                        <li><a href="#" style="color: #fff;">WORK</a></li>
                        <li><a href="#" style="color: #fff;">CONTACT US</a></li>     
                </div> 
            </div>
            <div class="col-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 mt-5">
              
                    <a href="#"><i class="lni-facebook-filled"></i></a>
                   <a href="#"><i class="lni-twitter-original"></i></a>
                    <a href="#"><i class="lni-instagram-original"></i></a>
                   <a href="#"><i class="lni-linkedin-original"></i></a>
               
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                
            </div>
        </div>
    </div>
        <!-- <div class="footer-copyright">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="footer-logo text-center mt-10">
                            <a href="index.html"><img src="<//?=base_url('assets/images/logo/LOGO_SENTIMETER_footer.png');?>" alt="Logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                    <div class="footer-link">
                            <h6 class="footer-title"style="color: #fff;"></h6>
                   
                                <li><a href="#" style="color: #fff;">HOME</a></li>
                                <li><a href="#" style="color: #fff;">SERVICE</a></li>
                                <li><a href="#" style="color: #fff;">WORK</a></li>
                                <li><a href="#" style="color: #fff;">CONTACT US</a></li>
                            
                        </div> 
                    </div>
                    <div class="col-lg-5">
                        <ul class="social text-center text-lg-right mt-10">
                            <li><a href="#"><i class="lni-facebook-filled"></i></a></li>
                            <li><a href="#"><i class="lni-twitter-original"></i></a></li>
                            <li><a href="#"><i class="lni-instagram-original"></i></a></li>
                            <li><a href="#"><i class="lni-linkedin-original"></i></a></li>
                        </ul> 
                    </div>
                </div> 
            </div> 
        </div>  -->
    </footer>


    <a href="#" class="back-to-top"><i class="lni-chevron-up"></i></a>


