
<body style="background-image: url(assets/images/background/bg_sen.png);background-position: inherit;background-size: cover;">



<!-- banner -->
<section id="hero">
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block" src="<?=base_url('assets/images/banner/banner_sevice.png');?>" alt="First slide" style="width: 100%;">
    </div>
  </div>
</div>
</section>
<!-- end -->

<!-- se1 -->
<section class="mt-5 pt-5 mb-5 pb-5"> 
    <div class="container">
        <div class="row">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <h1 class="head-about">SERVICE</h1>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5"></div>
        </div><!-- se row 1 -->
        <div class="row mt-3">
            <div class="col-12 col-sm-12 col-md-2 col-lg-2 col-xl-2"></div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
            <div class="col-12 col-sm-12 col-md-5 col-lg-5 col-xl-5">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
        </div><!-- se row 2 -->
    </div>
</section>
<!-- end se1 -->

<!-- se2 -->
<section class="mt-5 pt-5 "> 
    <div class="container">
        <div class="row mt-3">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <img src="<?=base_url('assets/images/service/design.jpg');?>" style="width: 100%;" class="img-fluid ">
            </div>
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6"style="margin-top: 14rem;">
                <h1 class="head-about">SERVICE</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
        </div><!-- se row 2 -->
    </div>
</section>
<!-- end se2 -->

<!-- se3 -->
<section class=" mb-5 pb-5"> 
    <div class="container">
        <div class="row mt-3">
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <img src="<?=base_url('assets/images/service/De.jpg');?>" style="width: 100%;" class="img-fluid ">
            </div>
            <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6" style="margin-top: 14rem;">
                <h1 class="head-about">SERVICE</h1>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
            </div>
        </div><!-- se row 2 -->
    </div>
</section>
<!-- end se3 -->
</body>

